export default [
    {id:1, subject: 'Math', location: 'London',price: "100",spaces: 10,image: 'icon.png'},
    {id:2, subject: 'English', location: 'Bristol',price: "120",spaces: 5,image: 'eng.png'},
    {id:3, subject: 'Music', location: 'Oxford',price: "130",spaces: 8,image: 'music.png'},
    {id:4, subject: 'Science', location: 'London',price: "150",spaces: 6,image: 'sci.png'},
    {id:5, subject: 'History', location: 'Oxford',price: "110",spaces: 9,image: 'hist.png'},
    {id:6, subject: 'Math', location: 'Bristol',price: "160",spaces: 9,image: 'icon.png'},
    {id:7, subject: 'Math', location: 'Leeds',price: "170",spaces: 10,image: 'icon.png'},
    {id:8, subject: 'English', location: 'Oxford',price: "115",spaces: 5,image: 'eng.png'},
    {id:9, subject: 'Music', location: 'London',price: "105",spaces: 7,image: 'music.png'},
    {id:10, subject: 'Science', location: 'Leeds',price: "165",spaces: 8,image: 'sci.png'},
    {id:11, subject: 'History', location: 'London',price: "185",spaces: 6,image: 'hist.png'},
    {id:12, subject: 'Computer', location: 'Leeds',price: "190",spaces: 9,image: 'cs.png'},
]

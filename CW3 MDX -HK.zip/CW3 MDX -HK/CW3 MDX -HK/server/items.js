export default [
    {id:1, Subject: 'Maths', Location: 'London',Price: "150",Space : 5,image: 'images/Maths.jpg'},
    {id:2, Subject: 'Biology', Location: 'Hendon',Price: "200",Space : 4 ,image: 'images/Biology.jpg'},
    {id:3, Subject: 'Computer Science', Location: 'London',Price: "250",Space : 3 ,image: 'images/ComputerScience.jpg'},
    {id:4, Subject: 'AI', Location: 'Birmingham',Price: "220",Space : 5,image: 'images/Artificial Intelligence.jpg'},
    {id:5, Subject: 'Synoptics', Location: 'Bristol',Price: "80",Space : 5,image: 'images/Synoptics.jpg'},
    {id:6, Subject: 'Music', Location: 'Birmingham',Price: "90",Space : 5,image: 'images/Music.jpg'},
    {id:7, Subject: 'Networking', Location: 'York',Price: "160",Space : 5,image: 'images/Networking.jpg'},
    {id:8, Subject: 'Web Application', Location: 'Essex',Price: "230",Space : 5,image: 'images/Web.jpg'},
    {id:9, Subject: 'Geography', Location: 'Oxford',Price: "70",Space : 5,image: 'images/geography.jpg'},
    {id:10, Subject: 'Secure System', Location: 'London',Price: "145",Space :5 ,image: 'images/DesignSecureSystem'},
    {id:11, Subject: 'Dancing', Location: 'London',Price: "140",Space : 5,image: 'images/Dancing.jpg'},
    {id:12, Subject: 'Singing', Location: 'Bristol',Price: "123",Space : 5,image: 'images/Singing.jpg'},
]
